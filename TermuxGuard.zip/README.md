# TermuxGuard

Aplikasi Android (Kotlin, native) yang berfungsi sebagai **dashboard kontrol untuk Termux** — ditujukan untuk belajar network engineering & cybersecurity defensif (recon, web security scanning, system/package management, monitoring & defense) langsung dari HP, tanpa perlu mengetik perintah manual satu per satu.

> **TermuxGuard tidak menjalankan shell sendiri.** Setiap tombol "Jalankan" membangun satu baris perintah lalu mengirimkannya ke aplikasi **Termux** lewat `RUN_COMMAND` intent resmi — persis seperti Anda mengetiknya sendiri di terminal Termux. Semua sandbox, izin, dan eksekusi tetap sepenuhnya dikendalikan oleh Termux.

---

## ⚠️ Legal & Etika — baca dulu

Tools yang terintegrasi (`nmap`, `nikto`, `sqlmap`, `httpx`, dsb.) adalah tools keamanan jaringan standar industri. Tools ini **hanya boleh digunakan terhadap sistem/website milik Anda sendiri, atau yang sudah memberi izin tertulis untuk diuji** (misalnya lab pribadi, program bug bounty resmi, atau server pribadi).

Menguji/menyerang sistem milik orang lain tanpa izin adalah **pelanggaran hukum** di hampir semua negara, termasuk Indonesia (diatur dalam UU ITE). Aplikasi ini dibuat untuk **tujuan edukasi** — setiap tool berisiko tinggi (ditandai `IZIN WAJIB`) mengharuskan Anda mencentang pernyataan izin secara eksplisit sebelum bisa dijalankan.

---

## Fitur

- **Katalog tools terorganisir per kategori**: Network Recon, Web Security Scan, System & Package Manager, Monitoring & Defense.
- **Form input dinamis** untuk tiap tool (target, port, level, dsb.) dengan preview perintah sebelum dijalankan.
- **Console output real-time** — hasil `stdout`/`stderr`/exit code dari Termux ditampilkan kembali di dalam app.
- **Tab "Cara Pakai" & "Analisis Hasil"** di setiap tool — dokumentasi lengkap: fungsi, cara pakai, cara membaca output, kapan dipakai, dan catatan legal. Dirancang sebagai materi belajar, bukan cuma eksekutor perintah.
- **Package Manager bawaan Termux**: `pkg update`, `pkg upgrade`, `pkg search`, `pkg install` langsung dari UI.
- **Import ZIP**: pilih file `.zip` (skrip custom, wordlist, dsb.) dari penyimpanan HP, otomatis disalin & diekstrak ke home directory Termux.
- **Tema gelap ala terminal**, dioptimalkan untuk layar HP.

## Daftar Tools

| Kategori | Tools |
|---|---|
| Network Recon | Nmap (host discovery, port scan, service/OS detection), Dig, Whois, Traceroute |
| Web Security Scan | Curl header check, httpx, Nikto, SQLMap |
| System & Package Manager | pkg update/upgrade/install/search, Git clone, htop |
| Monitoring & Defense | Cek port terbuka (`ss`), daftar proses, disk usage, pantau log SSH (fail2ban-style) |

Daftar lengkap beserta command template ada di [`ToolRepository.kt`](app/src/main/java/com/termuxguard/app/model/ToolRepository.kt), dokumentasi tiap tool di [`app/src/main/assets/docs/`](app/src/main/assets/docs/).

---

## Prasyarat di HP

1. **Install Termux** dari [F-Droid](https://f-droid.org/packages/com.termux/) (⚠️ bukan dari Play Store, versi Play Store sudah tidak dikembangkan dan sering bermasalah).
2. Buka Termux sekali, lalu jalankan:
   ```bash
   pkg update -y
   termux-setup-storage      # untuk fitur import ZIP
   ```
3. Edit `~/.termux/termux.properties` (buat jika belum ada), tambahkan baris:
   ```
   allow-external-apps=true
   ```
   Lalu jalankan `termux-reload-settings`.
4. Install tools yang ingin dipakai, misalnya:
   ```bash
   pkg install nmap nikto dnsutils whois traceroute git htop openssh iproute2 -y
   pip install sqlmap --break-system-packages
   ```
   (atau install langsung dari dalam TermuxGuard lewat menu **Package Manager**.)
5. Install **TermuxGuard.apk** (hasil build, lihat di bawah) dan buka. Saat pertama kali menjalankan sebuah tool, Android akan menampilkan dialog izin dari Termux untuk mengizinkan `RUN_COMMAND` — tekan **Allow/Izinkan**.

---

## Build dari source

### Lewat Android Studio
1. Clone repo ini, buka dengan Android Studio (Giraffe+ / AGP 8.5+, JDK 17).
2. Biarkan Gradle sync, lalu **Run** ke device/emulator, atau **Build > Generate Signed Bundle/APK**.

### Lewat command line
```bash
git clone https://github.com/<akun-anda>/TermuxGuard.git
cd TermuxGuard
./gradlew assembleDebug
# APK ada di: app/build/outputs/apk/debug/app-debug.apk
```

### Lewat GitHub Actions (otomatis)
Repo ini sudah dilengkapi `.github/workflows/android-build.yml`. Setiap push ke branch `main` (atau manual lewat tab **Actions > Run workflow**) akan:
1. Build APK debug & release (unsigned).
2. Build ulang seluruh source code jadi `TermuxGuard-source.zip`.
3. Semua hasil tersedia sebagai **Artifacts** di halaman run workflow — tinggal download.

---

## Struktur Proyek

```
TermuxGuard/
├── app/
│   ├── src/main/java/com/termuxguard/app/
│   │   ├── core/        # Integrasi Termux (RUN_COMMAND, result receiver, pub/sub)
│   │   ├── model/        # Katalog tools & data model
│   │   ├── ui/            # Activities & adapters
│   │   └── util/         # Zip import, markdown docs loader
│   ├── src/main/assets/docs/   # Dokumentasi & analisis tiap tool (markdown)
│   └── src/main/res/           # Layout, string, tema
├── .github/workflows/android-build.yml
└── README.md
```

## Cara kerja teknis singkat

1. User mengisi parameter di form (mis. target IP) → `ToolRepository.buildCommand()` merangkai command string dari template, dengan sanitasi karakter shell berbahaya (`; | & \` $() < >`).
2. `TermuxCommandExecutor.run()` mengirim `Intent` eksplisit ke `com.termux/.app.RunCommandService` dengan action `com.termux.RUN_COMMAND`, menyertakan `PendingIntent` agar Termux bisa mengirim balik hasilnya.
3. Termux mengeksekusi perintah di shell-nya sendiri (bash), lalu memanggil kembali `PendingIntent` dengan bundle berisi `stdout`, `stderr`, `exitCode`.
4. `TermuxResultReceiver` menerima broadcast tersebut dan mempublikasikannya lewat `CommandResultBus`, yang didengarkan oleh layar yang sedang aktif untuk menampilkan output di console.

Referensi resmi: [Termux RUN_COMMAND Intent Wiki](https://github.com/termux/termux-app/wiki/RUN_COMMAND-Intent).

## Lisensi

MIT — gunakan, modifikasi, dan distribusikan secara bebas untuk tujuan edukasi. Lihat [LICENSE](LICENSE).
