# Keep model classes used for JSON-like in-app catalogs
-keep class com.termuxguard.app.model.** { *; }
