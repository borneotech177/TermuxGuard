package com.termuxguard.app.ui

import android.net.Uri
import android.os.Bundle
import android.provider.OpenableColumns
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import com.termuxguard.app.core.CommandResult
import com.termuxguard.app.core.CommandResultBus
import com.termuxguard.app.core.RunCommandPermissionDelegate
import com.termuxguard.app.core.TermuxCommandExecutor
import com.termuxguard.app.databinding.ActivityZipImportBinding
import com.termuxguard.app.util.ZipImportUtil
import java.util.UUID

class ZipImportActivity : AppCompatActivity() {

    private lateinit var binding: ActivityZipImportBinding
    private var pickedUri: Uri? = null
    private var pickedName: String = "import.zip"
    private var currentJobId: String? = null
    private val runCommand = RunCommandPermissionDelegate(this)

    private val resultListener: (CommandResult) -> Unit = { result ->
        if (result.jobId == currentJobId) {
            runOnUiThread { showExtractResult(result) }
        }
    }

    private val pickZipLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) onZipPicked(uri)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityZipImportBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.importLog.text = "Catatan: jalankan 'termux-setup-storage' sekali di Termux agar folder " +
            "~/storage/downloads tersedia, sebelum melakukan import pertama kali."

        binding.pickZipButton.setOnClickListener {
            pickZipLauncher.launch(arrayOf("application/zip", "application/x-zip-compressed"))
        }

        binding.extractButton.setOnClickListener { onExtractClicked() }
    }

    override fun onStart() {
        super.onStart()
        CommandResultBus.subscribe(resultListener)
    }

    override fun onStop() {
        super.onStop()
        CommandResultBus.unsubscribe(resultListener)
    }

    private fun onZipPicked(uri: Uri) {
        pickedUri = uri
        pickedName = queryFileName(uri) ?: "import_${System.currentTimeMillis()}.zip"
        binding.selectedFileText.text = "Dipilih: $pickedName"
        binding.extractButton.isEnabled = true
    }

    private fun queryFileName(uri: Uri): String? {
        return contentResolver.query(uri, null, null, null, null)?.use { cursor ->
            val idx = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (idx >= 0 && cursor.moveToFirst()) cursor.getString(idx) else null
        }
    }

    private fun onExtractClicked() {
        val uri = pickedUri ?: return
        if (!TermuxCommandExecutor.isTermuxInstalled(this)) {
            Toast.makeText(this, getString(com.termuxguard.app.R.string.termux_not_installed_msg), Toast.LENGTH_LONG).show()
            return
        }

        binding.importLog.text = "Menyalin $pickedName ke Downloads..."
        val copyResult = ZipImportUtil.copyToDownloads(this, uri, pickedName)
        binding.importLog.append("\n${copyResult.message}")

        if (!copyResult.success) return

        val command = ZipImportUtil.buildExtractCommand(copyResult.fileName)
        val jobId = UUID.randomUUID().toString()
        currentJobId = jobId
        binding.importLog.append("\n\n$ $command\n(mengekstrak di Termux...)")
        runCommand.dispatch {
            TermuxCommandExecutor.run(this, jobId, command, TermuxCommandExecutor.SessionMode.BACKGROUND, label = "Import ZIP")
        }
    }

    private fun showExtractResult(result: CommandResult) {
        val sb = StringBuilder()
        if (result.stdout.isNotBlank()) sb.append(result.stdout).append("\n")
        if (result.stderr.isNotBlank()) sb.append("--- stderr ---\n").append(result.stderr).append("\n")
        sb.append("[exit code: ${result.exitCode}]")
        binding.importLog.text = sb.toString()
    }
}
