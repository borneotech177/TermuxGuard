package com.termuxguard.app.util

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import java.io.File
import java.io.FileOutputStream

/**
 * Copies a ZIP file picked through the Storage Access Framework into the
 * shared Downloads folder, so Termux (after `termux-setup-storage`) can
 * see it at ~/storage/downloads/<name>.zip and extract it with `unzip`.
 *
 * TermuxGuard itself never touches Termux's private files directory —
 * it only stages the file somewhere Termux's own shared-storage symlinks
 * already expose, exactly as if the user copied the file there manually.
 */
object ZipImportUtil {

    data class CopyResult(val success: Boolean, val fileName: String, val message: String)

    fun copyToDownloads(context: Context, sourceUri: Uri, desiredName: String): CopyResult {
        val fileName = if (desiredName.endsWith(".zip")) desiredName else "$desiredName.zip"

        return try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                copyViaMediaStore(context, sourceUri, fileName)
            } else {
                copyViaLegacyPath(context, sourceUri, fileName)
            }
        } catch (e: Exception) {
            CopyResult(false, fileName, "Gagal menyalin file: ${e.message}")
        }
    }

    private fun copyViaMediaStore(context: Context, sourceUri: Uri, fileName: String): CopyResult {
        val resolver = context.contentResolver
        val values = ContentValues().apply {
            put(MediaStore.Downloads.DISPLAY_NAME, fileName)
            put(MediaStore.Downloads.MIME_TYPE, "application/zip")
            put(MediaStore.Downloads.IS_PENDING, 1)
        }
        val collection = MediaStore.Downloads.EXTERNAL_CONTENT_URI
        val itemUri = resolver.insert(collection, values)
            ?: return CopyResult(false, fileName, "Tidak bisa membuat file tujuan di Downloads")

        resolver.openOutputStream(itemUri).use { out ->
            context.contentResolver.openInputStream(sourceUri).use { input ->
                if (input == null || out == null) {
                    return CopyResult(false, fileName, "Tidak bisa membaca file sumber")
                }
                input.copyTo(out)
            }
        }
        values.clear()
        values.put(MediaStore.Downloads.IS_PENDING, 0)
        resolver.update(itemUri, values, null, null)

        return CopyResult(true, fileName, "Tersalin ke Downloads/$fileName")
    }

    private fun copyViaLegacyPath(context: Context, sourceUri: Uri, fileName: String): CopyResult {
        val downloadsDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        if (!downloadsDir.exists()) downloadsDir.mkdirs()
        val destFile = File(downloadsDir, fileName)

        context.contentResolver.openInputStream(sourceUri).use { input ->
            if (input == null) return CopyResult(false, fileName, "Tidak bisa membaca file sumber")
            FileOutputStream(destFile).use { out -> input.copyTo(out) }
        }
        return CopyResult(true, fileName, "Tersalin ke ${destFile.absolutePath}")
    }

    /**
     * Shell command Termux runs to extract the staged zip. Requires the user
     * to have run `termux-setup-storage` once so ~/storage/downloads exists.
     */
    fun buildExtractCommand(fileName: String, destDir: String = "termuxguard-imports"): String {
        val safeFile = fileName.replace(Regex("[^A-Za-z0-9._-]"), "_")
        return "mkdir -p ~/$destDir && " +
            "unzip -o ~/storage/downloads/$safeFile -d ~/$destDir && " +
            "echo '--- isi $destDir ---' && ls -la ~/$destDir"
    }
}
