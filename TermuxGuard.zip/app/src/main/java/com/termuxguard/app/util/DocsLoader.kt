package com.termuxguard.app.util

import android.content.Context
import java.io.BufferedReader
import java.io.InputStreamReader

/**
 * Loads the bundled per-tool markdown docs from the assets/docs folder (.md files).
 * Rendered as plain, lightly-formatted text (no external markdown lib needed)
 * since these docs are short usage/analysis notes, not rich documents.
 */
object DocsLoader {

    fun read(context: Context, assetPath: String): String {
        return try {
            context.assets.open(assetPath).use { input ->
                BufferedReader(InputStreamReader(input)).readText()
            }
        } catch (e: Exception) {
            "Dokumentasi belum tersedia untuk tool ini."
        }
    }

    /** Pulls out the "## Membaca hasil" (and similar) section for the Analysis tab. */
    fun extractSection(markdown: String, headingKeywords: List<String>): String {
        val lines = markdown.lines()
        val builder = StringBuilder()
        var capturing = false
        for (line in lines) {
            val isHeading = line.trim().startsWith("#")
            if (isHeading) {
                capturing = headingKeywords.any { line.contains(it, ignoreCase = true) }
                if (capturing) continue
            }
            if (capturing) builder.appendLine(line)
        }
        val result = builder.toString().trim()
        return result.ifBlank { "Belum ada catatan analisis khusus — lihat tab Cara Pakai untuk detail lengkap." }
    }
}
