package com.termuxguard.app.core

import android.app.NotificationManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Bundle
import androidx.core.app.NotificationCompat
import com.termuxguard.app.R
import com.termuxguard.app.TermuxGuardApp

/**
 * Receives the result PendingIntent Termux fires once a background
 * RUN_COMMAND job finishes. The payload shape is defined by Termux's
 * `com.termux.shared.shell.command.result.ResultConfig` / `ResultData`:
 * a "result" Bundle containing stdout, stderr, exitCode and errmsg.
 */
class TermuxResultReceiver : BroadcastReceiver() {

    override fun onReceive(context: Context, intent: Intent) {
        val jobId = intent.getStringExtra(EXTRA_JOB_ID) ?: "unknown"
        val resultBundle: Bundle? = intent.getBundleExtra("result")

        val stdout = resultBundle?.getString("stdout").orEmpty()
        val stderr = resultBundle?.getString("stderr").orEmpty()
        val exitCode = resultBundle?.getInt("exitCode", -1) ?: -1
        val errmsg = resultBundle?.getString("errmsg").orEmpty()

        val result = CommandResult(jobId, stdout, stderr, exitCode, errmsg)
        CommandResultBus.publish(result)
        notifyDone(context, jobId, exitCode)
    }

    private fun notifyDone(context: Context, jobId: String, exitCode: Int) {
        val manager = context.getSystemService(NotificationManager::class.java) ?: return
        val success = exitCode == 0
        val notification = NotificationCompat.Builder(context, TermuxGuardApp.CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle(if (success) "Selesai: $jobId" else "Gagal (exit $exitCode): $jobId")
            .setContentText("Ketuk untuk lihat output di TermuxGuard")
            .setAutoCancel(true)
            .build()
        manager.notify(jobId.hashCode(), notification)
    }

    companion object {
        const val EXTRA_JOB_ID = "extra_job_id"
    }
}
