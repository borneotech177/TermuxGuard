package com.termuxguard.app.core

import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build

/**
 * Thin wrapper around Termux's official RUN_COMMAND intent API.
 *
 * TermuxGuard never executes anything by itself: it always hands a command
 * string off to the real Termux app, which owns the shell, the filesystem
 * sandbox and the user's own package installation. This keeps the trust
 * boundary exactly where Termux already puts it (RUN_COMMAND must be
 * explicitly allowed by the user in ~/.termux/termux.properties).
 *
 * Reference: https://github.com/termux/termux-app/wiki/RUN_COMMAND-Intent
 */
object TermuxCommandExecutor {

    private const val TERMUX_PACKAGE = "com.termux"
    private const val RUN_COMMAND_SERVICE = "com.termux.app.RunCommandService"
    private const val ACTION_RUN_COMMAND = "com.termux.RUN_COMMAND"

    private const val EXTRA_COMMAND_PATH = "com.termux.RUN_COMMAND_PATH"
    private const val EXTRA_COMMAND_ARGUMENTS = "com.termux.RUN_COMMAND_ARGUMENTS"
    private const val EXTRA_COMMAND_WORKDIR = "com.termux.RUN_COMMAND_WORKDIR"
    private const val EXTRA_COMMAND_BACKGROUND = "com.termux.RUN_COMMAND_BACKGROUND"
    private const val EXTRA_COMMAND_SESSION_ACTION = "com.termux.RUN_COMMAND_SESSION_ACTION"
    private const val EXTRA_COMMAND_LABEL = "com.termux.RUN_COMMAND_COMMAND_LABEL"
    private const val EXTRA_COMMAND_DESCRIPTION = "com.termux.RUN_COMMAND_COMMAND_DESCRIPTION"
    private const val EXTRA_PENDING_INTENT = "com.termux.RUN_COMMAND_PENDING_INTENT"

    private const val BASH_PATH = "/data/data/com.termux/files/usr/bin/bash"
    private const val HOME_DIR = "/data/data/com.termux/files/home"

    enum class SessionMode(val value: String) {
        /** Runs silently, Termux posts the result back via PendingIntent. */
        BACKGROUND("0"),
        /** Opens/activates a new foreground Termux session so the user watches it live. */
        NEW_SESSION("1")
    }

    fun isTermuxInstalled(context: Context): Boolean {
        return try {
            context.packageManager.getPackageInfo(TERMUX_PACKAGE, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    /**
     * Runs an arbitrary shell command line inside Termux.
     *
     * @param jobId      correlation id, returned inside the result bundle so the
     *                   UI can match a result back to the request that started it.
     * @param shellLine  full shell command, e.g. "nmap -sV 192.168.1.1"
     * @param mode       BACKGROUND (headless, result delivered to TermuxResultReceiver)
     *                   or NEW_SESSION (opens Termux so the user watches raw output).
     */
    fun run(
        context: Context,
        jobId: String,
        shellLine: String,
        mode: SessionMode = SessionMode.BACKGROUND,
        label: String = "TermuxGuard"
    ) {
        val intent = Intent(ACTION_RUN_COMMAND).apply {
            setClassName(TERMUX_PACKAGE, RUN_COMMAND_SERVICE)
            putExtra(EXTRA_COMMAND_PATH, BASH_PATH)
            putExtra(EXTRA_COMMAND_ARGUMENTS, arrayOf("-c", shellLine))
            putExtra(EXTRA_COMMAND_WORKDIR, HOME_DIR)
            putExtra(EXTRA_COMMAND_BACKGROUND, mode == SessionMode.BACKGROUND)
            putExtra(EXTRA_COMMAND_SESSION_ACTION, mode.value)
            putExtra(EXTRA_COMMAND_LABEL, label)
            putExtra(EXTRA_COMMAND_DESCRIPTION, shellLine)

            if (mode == SessionMode.BACKGROUND) {
                val resultIntent = Intent(context, TermuxResultReceiver::class.java).apply {
                    putExtra(TermuxResultReceiver.EXTRA_JOB_ID, jobId)
                }
                val flags = PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                val pendingIntent = PendingIntent.getBroadcast(
                    context,
                    jobId.hashCode(),
                    resultIntent,
                    flags
                )
                putExtra(EXTRA_PENDING_INTENT, pendingIntent)
            }
        }

        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            context.startForegroundService(intent)
        } else {
            context.startService(intent)
        }
    }

    /** Convenience for `pkg update/upgrade/install` style package-manager calls. */
    fun runPkg(context: Context, jobId: String, pkgArgs: String) {
        run(context, jobId, "pkg $pkgArgs -y", SessionMode.BACKGROUND, label = "pkg $pkgArgs")
    }

    fun componentName(): ComponentName = ComponentName(TERMUX_PACKAGE, RUN_COMMAND_SERVICE)
}
