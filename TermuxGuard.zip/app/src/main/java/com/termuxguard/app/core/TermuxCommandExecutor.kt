package com.termuxguard.app.core

import android.app.PendingIntent
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

/**
 * Thin wrapper around Termux's official RUN_COMMAND intent API.
 *
 * TermuxGuard never executes anything by itself: it always hands a command
 * string off to the real Termux app, which owns the shell, the filesystem
 * sandbox and the user's own package installation. This keeps the trust
 * boundary exactly where Termux already puts it (RUN_COMMAND must be
 * explicitly allowed by the user in ~/.termux/termux.properties).
 *
 * Reference: https://github.com/termux/termux-app/wiki/RUN_COMMAND-Intent
 */
object TermuxCommandExecutor {

    /**
     * Termux declares this as a "dangerous" protection-level permission, so
     * it must be requested at RUNTIME (like camera/location), not just listed
     * in the manifest. Forgetting this makes the first RUN_COMMAND call throw
     * a SecurityException and crash the app.
     */
    const val PERMISSION_RUN_COMMAND = "com.termux.permission.RUN_COMMAND"

    private const val TERMUX_PACKAGE = "com.termux"
    private const val RUN_COMMAND_SERVICE = "com.termux.app.RunCommandService"
    private const val ACTION_RUN_COMMAND = "com.termux.RUN_COMMAND"

    private const val EXTRA_COMMAND_PATH = "com.termux.RUN_COMMAND_PATH"
    private const val EXTRA_COMMAND_ARGUMENTS = "com.termux.RUN_COMMAND_ARGUMENTS"
    private const val EXTRA_COMMAND_WORKDIR = "com.termux.RUN_COMMAND_WORKDIR"
    private const val EXTRA_COMMAND_BACKGROUND = "com.termux.RUN_COMMAND_BACKGROUND"
    private const val EXTRA_COMMAND_SESSION_ACTION = "com.termux.RUN_COMMAND_SESSION_ACTION"
    private const val EXTRA_COMMAND_LABEL = "com.termux.RUN_COMMAND_COMMAND_LABEL"
    private const val EXTRA_COMMAND_DESCRIPTION = "com.termux.RUN_COMMAND_COMMAND_DESCRIPTION"
    private const val EXTRA_PENDING_INTENT = "com.termux.RUN_COMMAND_PENDING_INTENT"

    private const val BASH_PATH = "/data/data/com.termux/files/usr/bin/bash"
    private const val HOME_DIR = "/data/data/com.termux/files/home"

    enum class SessionMode(val value: String) {
        /** Runs silently, Termux posts the result back via PendingIntent. */
        BACKGROUND("0"),
        /** Opens/activates a new foreground Termux session so the user watches it live. */
        NEW_SESSION("1")
    }

    /** Result of attempting to dispatch a command — callers use this instead of a crash. */
    sealed class RunOutcome {
        object Started : RunOutcome()
        /** Caller must request [PERMISSION_RUN_COMMAND] at runtime, then retry. */
        object PermissionRequired : RunOutcome()
        data class Failed(val reason: String) : RunOutcome()
    }

    fun isTermuxInstalled(context: Context): Boolean {
        return try {
            context.packageManager.getPackageInfo(TERMUX_PACKAGE, 0)
            true
        } catch (e: PackageManager.NameNotFoundException) {
            false
        }
    }

    fun hasRunCommandPermission(context: Context): Boolean {
        return ContextCompat.checkSelfPermission(context, PERMISSION_RUN_COMMAND) ==
            PackageManager.PERMISSION_GRANTED
    }

    /**
     * Runs an arbitrary shell command line inside Termux.
     *
     * @param jobId      correlation id, returned inside the result bundle so the
     *                   UI can match a result back to the request that started it.
     * @param shellLine  full shell command, e.g. "nmap -sV 192.168.1.1"
     * @param mode       BACKGROUND (headless, result delivered to TermuxResultReceiver)
     *                   or NEW_SESSION (opens Termux so the user watches raw output).
     *
     * Never throws: any failure (missing permission, Termux not installed,
     * Termux refusing the intent, etc.) is reported back as a [RunOutcome]
     * instead of crashing the app.
     */
    fun run(
        context: Context,
        jobId: String,
        shellLine: String,
        mode: SessionMode = SessionMode.BACKGROUND,
        label: String = "TermuxGuard"
    ): RunOutcome {
        if (!isTermuxInstalled(context)) {
            return RunOutcome.Failed("Termux belum terpasang di perangkat ini.")
        }
        if (!hasRunCommandPermission(context)) {
            return RunOutcome.PermissionRequired
        }

        return try {
            val intent = Intent(ACTION_RUN_COMMAND).apply {
                setClassName(TERMUX_PACKAGE, RUN_COMMAND_SERVICE)
                putExtra(EXTRA_COMMAND_PATH, BASH_PATH)
                putExtra(EXTRA_COMMAND_ARGUMENTS, arrayOf("-c", shellLine))
                putExtra(EXTRA_COMMAND_WORKDIR, HOME_DIR)
                putExtra(EXTRA_COMMAND_BACKGROUND, mode == SessionMode.BACKGROUND)
                putExtra(EXTRA_COMMAND_SESSION_ACTION, mode.value)
                putExtra(EXTRA_COMMAND_LABEL, label)
                putExtra(EXTRA_COMMAND_DESCRIPTION, shellLine)

                if (mode == SessionMode.BACKGROUND) {
                    val resultIntent = Intent(context, TermuxResultReceiver::class.java).apply {
                        putExtra(TermuxResultReceiver.EXTRA_JOB_ID, jobId)
                    }
                    val flags = PendingIntent.FLAG_MUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
                    val pendingIntent = PendingIntent.getBroadcast(
                        context,
                        jobId.hashCode(),
                        resultIntent,
                        flags
                    )
                    putExtra(EXTRA_PENDING_INTENT, pendingIntent)
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                context.startForegroundService(intent)
            } else {
                context.startService(intent)
            }
            RunOutcome.Started
        } catch (e: SecurityException) {
            RunOutcome.Failed("Termux menolak izin RUN_COMMAND: ${e.message}")
        } catch (e: IllegalStateException) {
            RunOutcome.Failed("Tidak bisa memulai service Termux (coba buka Termux dulu secara manual sekali): ${e.message}")
        } catch (e: Exception) {
            RunOutcome.Failed("Gagal menjalankan perintah: ${e.message}")
        }
    }

    /** Convenience for `pkg update/upgrade/install` style package-manager calls. */
    fun runPkg(context: Context, jobId: String, pkgArgs: String): RunOutcome {
        return run(context, jobId, "pkg $pkgArgs -y", SessionMode.BACKGROUND, label = "pkg $pkgArgs")
    }

    fun componentName(): ComponentName = ComponentName(TERMUX_PACKAGE, RUN_COMMAND_SERVICE)
}
