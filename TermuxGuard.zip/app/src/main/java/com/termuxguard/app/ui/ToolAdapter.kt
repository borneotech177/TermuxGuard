package com.termuxguard.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.termuxguard.app.databinding.ItemToolBinding
import com.termuxguard.app.model.RiskLevel
import com.termuxguard.app.model.ToolItem

class ToolAdapter(
    private val tools: List<ToolItem>,
    private val onClick: (ToolItem) -> Unit
) : RecyclerView.Adapter<ToolAdapter.VH>() {

    inner class VH(val binding: ItemToolBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemToolBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val tool = tools[position]
        holder.binding.toolName.text = tool.name
        holder.binding.toolDesc.text = tool.shortDescription
        holder.binding.riskBadge.text = when (tool.risk) {
            RiskLevel.INFO -> "INFO"
            RiskLevel.CAUTION -> "HATI-HATI"
            RiskLevel.AUTHORIZED_ONLY -> "IZIN WAJIB"
        }
        holder.binding.root.setOnClickListener { onClick(tool) }
    }

    override fun getItemCount(): Int = tools.size
}
