package com.termuxguard.app.core

import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/**
 * Wraps the runtime-permission dance required before any
 * [TermuxCommandExecutor.run] call can succeed, so every screen that
 * launches a command handles "permission not granted yet" the same way
 * instead of letting a SecurityException crash the app.
 *
 * Usage inside an AppCompatActivity:
 *   private val runCommand = RunCommandPermissionDelegate(this)
 *   ...
 *   runCommand.dispatch { TermuxCommandExecutor.run(this, jobId, cmd, mode, label) }
 */
class RunCommandPermissionDelegate(private val activity: AppCompatActivity) {

    private var pending: (() -> TermuxCommandExecutor.RunOutcome)? = null
    private var onStarted: (() -> Unit)? = null

    private val permissionLauncher = activity.registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            pending?.let { action -> handleOutcome(action(), action) }
        } else {
            Toast.makeText(
                activity,
                "Izin RUN_COMMAND ditolak — TermuxGuard tidak bisa menjalankan perintah ke Termux tanpa izin ini.",
                Toast.LENGTH_LONG
            ).show()
        }
        pending = null
    }

    /**
     * Runs [action] (a call to TermuxCommandExecutor.run/runPkg). If Termux's
     * RUN_COMMAND permission hasn't been granted yet, this requests it and
     * automatically retries [action] once the user approves the system
     * dialog — the caller never has to think about the permission flow.
     *
     * [onRunStarted] fires only when the command was actually dispatched
     * (immediately, or after the permission is granted).
     */
    fun dispatch(onRunStarted: (() -> Unit)? = null, action: () -> TermuxCommandExecutor.RunOutcome) {
        onStarted = onRunStarted
        handleOutcome(action(), action)
    }

    private fun handleOutcome(outcome: TermuxCommandExecutor.RunOutcome, action: () -> TermuxCommandExecutor.RunOutcome) {
        when (outcome) {
            is TermuxCommandExecutor.RunOutcome.Started -> {
                onStarted?.invoke()
            }
            is TermuxCommandExecutor.RunOutcome.PermissionRequired -> {
                pending = action
                permissionLauncher.launch(TermuxCommandExecutor.PERMISSION_RUN_COMMAND)
            }
            is TermuxCommandExecutor.RunOutcome.Failed -> {
                Toast.makeText(activity, outcome.reason, Toast.LENGTH_LONG).show()
            }
        }
    }
}
