package com.termuxguard.app.model

/** One fill-in-the-blank argument shown as a text field before a tool runs. */
data class ToolParam(
    val key: String,
    val label: String,
    val hint: String,
    val defaultValue: String = "",
    val required: Boolean = true
)

enum class RiskLevel {
    /** Read-only / local info, safe against any host. */
    INFO,
    /** Sends traffic to a remote host; use only against systems you control or are authorized to test. */
    CAUTION,
    /** Active scanning/exploitation-style tooling; always gated behind the authorization checkbox. */
    AUTHORIZED_ONLY
}

data class ToolItem(
    val id: String,
    val categoryId: String,
    val name: String,
    val termuxPackage: String?,   // `pkg install <this>` if not already present; null = built into bash/coreutils
    val shortDescription: String,
    /** Shell template; {paramKey} gets substituted from the user's inputs. */
    val commandTemplate: String,
    val params: List<ToolParam> = emptyList(),
    val risk: RiskLevel = RiskLevel.INFO,
    val docsAsset: String,        // path under assets/docs/*.md
    val runInNewSession: Boolean = false // true = open visible Termux session instead of headless
)

data class ToolCategory(
    val id: String,
    val title: String,
    val description: String
)
