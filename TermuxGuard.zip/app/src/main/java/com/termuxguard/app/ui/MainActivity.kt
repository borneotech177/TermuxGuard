package com.termuxguard.app.ui

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.termuxguard.app.core.TermuxCommandExecutor
import com.termuxguard.app.databinding.ActivityMainBinding
import com.termuxguard.app.model.ToolRepository

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupCategoryList()
        setupBottomNav()
        checkTermuxInstalled()

        binding.swipeRefresh.setOnRefreshListener {
            checkTermuxInstalled()
            binding.swipeRefresh.isRefreshing = false
        }
    }

    override fun onResume() {
        super.onResume()
        checkTermuxInstalled()
    }

    private fun setupCategoryList() {
        binding.categoryRecycler.layoutManager = LinearLayoutManager(this)
        binding.categoryRecycler.adapter = CategoryAdapter(ToolRepository.categories) { category ->
            startActivity(
                Intent(this, ToolListActivity::class.java)
                    .putExtra(ToolListActivity.EXTRA_CATEGORY_ID, category.id)
            )
        }
    }

    private fun setupBottomNav() {
        binding.bottomNav.setOnItemSelectedListener { item ->
            when (item.itemId) {
                com.termuxguard.app.R.id.nav_tools -> true
                com.termuxguard.app.R.id.nav_package -> {
                    startActivity(Intent(this, PackageManagerActivity::class.java)); true
                }
                com.termuxguard.app.R.id.nav_import -> {
                    startActivity(Intent(this, ZipImportActivity::class.java)); true
                }
                com.termuxguard.app.R.id.nav_about -> {
                    startActivity(Intent(this, AboutActivity::class.java)); true
                }
                else -> false
            }
        }
    }

    private fun checkTermuxInstalled() {
        val installed = TermuxCommandExecutor.isTermuxInstalled(this)
        binding.statusBanner.visibility = if (installed) android.view.View.GONE else android.view.View.VISIBLE
        if (!installed) {
            binding.statusText.setText(com.termuxguard.app.R.string.termux_not_installed_msg)
            binding.statusAction.setOnClickListener {
                val uri = Uri.parse("https://f-droid.org/packages/com.termux/")
                startActivity(Intent(Intent.ACTION_VIEW, uri))
            }
        }
    }
}
