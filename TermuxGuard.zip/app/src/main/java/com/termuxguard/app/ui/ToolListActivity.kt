package com.termuxguard.app.ui

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.termuxguard.app.databinding.ActivityToolListBinding
import com.termuxguard.app.model.ToolRepository

class ToolListActivity : AppCompatActivity() {

    private lateinit var binding: ActivityToolListBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityToolListBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val categoryId = intent.getStringExtra(EXTRA_CATEGORY_ID) ?: return
        val category = ToolRepository.categories.find { it.id == categoryId } ?: return
        val tools = ToolRepository.toolsForCategory(categoryId)

        binding.toolbar.title = category.title
        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.categoryDesc.text = category.description

        binding.toolRecycler.layoutManager = LinearLayoutManager(this)
        binding.toolRecycler.adapter = ToolAdapter(tools) { tool ->
            startActivity(
                Intent(this, ToolDetailActivity::class.java)
                    .putExtra(ToolDetailActivity.EXTRA_TOOL_ID, tool.id)
            )
        }
    }

    companion object {
        const val EXTRA_CATEGORY_ID = "extra_category_id"
    }
}
