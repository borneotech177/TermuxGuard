package com.termuxguard.app.core

import java.util.concurrent.CopyOnWriteArrayList

data class CommandResult(
    val jobId: String,
    val stdout: String,
    val stderr: String,
    val exitCode: Int,
    val errmsg: String
)

/**
 * Tiny in-process pub/sub so TermuxResultReceiver (a fresh BroadcastReceiver
 * instance each time) can hand finished-job output back to whichever
 * Activity/ViewModel is currently showing the console.
 */
object CommandResultBus {

    private val listeners = CopyOnWriteArrayList<(CommandResult) -> Unit>()
    private val history = LinkedHashMap<String, CommandResult>()

    fun subscribe(listener: (CommandResult) -> Unit) {
        listeners.add(listener)
    }

    fun unsubscribe(listener: (CommandResult) -> Unit) {
        listeners.remove(listener)
    }

    fun publish(result: CommandResult) {
        synchronized(history) { history[result.jobId] = result }
        listeners.forEach { it(result) }
    }

    fun lastResultFor(jobId: String): CommandResult? = synchronized(history) { history[jobId] }
}
