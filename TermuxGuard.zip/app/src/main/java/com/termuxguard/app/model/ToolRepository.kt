package com.termuxguard.app.model

/**
 * Static catalog of every tool TermuxGuard can launch.
 *
 * Nothing here is a hidden/obfuscated payload: every entry is a one-line
 * call to a well-known, publicly documented CLI tool, exactly as you would
 * type it yourself inside Termux. TermuxGuard's job is only to remember the
 * right flags, collect parameters through a form, and show the matching
 * "cara pakai" (usage) + "cara baca hasil" (how to read the output) notes
 * next to the console so this doubles as a learning tool.
 */
object ToolRepository {

    val categories = listOf(
        ToolCategory(
            id = "recon",
            title = "Network Recon",
            description = "Pemetaan host, port, dan informasi domain. Titik awal setiap audit keamanan."
        ),
        ToolCategory(
            id = "websec",
            title = "Web Security Scan",
            description = "Cek kerentanan aplikasi web. WAJIB hanya pada target milik sendiri / yang diizinkan."
        ),
        ToolCategory(
            id = "system",
            title = "System & Package Manager",
            description = "Kelola paket Termux, repo git, dan environment."
        ),
        ToolCategory(
            id = "defense",
            title = "Monitoring & Defense",
            description = "Pantau port terbuka, proses, dan percobaan login mencurigakan di device sendiri."
        )
    )

    val tools: List<ToolItem> = listOf(

        // ---------------- RECON ----------------
        ToolItem(
            id = "nmap_ping",
            categoryId = "recon",
            name = "Nmap – Host Discovery",
            termuxPackage = "nmap",
            shortDescription = "Cek host mana saja yang hidup di sebuah subnet (ping scan).",
            commandTemplate = "nmap -sn {target}",
            params = listOf(ToolParam("target", "Target / subnet", "contoh: 192.168.1.0/24")),
            risk = RiskLevel.CAUTION,
            docsAsset = "docs/nmap_ping.md"
        ),
        ToolItem(
            id = "nmap_portscan",
            categoryId = "recon",
            name = "Nmap – Port Scan",
            termuxPackage = "nmap",
            shortDescription = "Scan port TCP umum pada satu host.",
            commandTemplate = "nmap -sV --top-ports {topPorts} {target}",
            params = listOf(
                ToolParam("target", "Target (IP/domain)", "contoh: 192.168.1.10"),
                ToolParam("topPorts", "Jumlah top ports", "contoh: 100", defaultValue = "100")
            ),
            risk = RiskLevel.AUTHORIZED_ONLY,
            docsAsset = "docs/nmap_portscan.md"
        ),
        ToolItem(
            id = "nmap_service",
            categoryId = "recon",
            name = "Nmap – Service/OS Detection (-A)",
            termuxPackage = "nmap",
            shortDescription = "Deteksi versi service, OS fingerprint, dan script default NSE.",
            commandTemplate = "nmap -A -T3 {target}",
            params = listOf(ToolParam("target", "Target (IP/domain)", "contoh: 192.168.1.10")),
            risk = RiskLevel.AUTHORIZED_ONLY,
            docsAsset = "docs/nmap_service.md"
        ),
        ToolItem(
            id = "dig_lookup",
            categoryId = "recon",
            name = "Dig – DNS Lookup",
            termuxPackage = "dnsutils",
            shortDescription = "Lihat record DNS (A, MX, TXT, NS, dst) sebuah domain.",
            commandTemplate = "dig {recordType} {target} +noall +answer",
            params = listOf(
                ToolParam("target", "Domain", "contoh: example.com"),
                ToolParam("recordType", "Tipe record", "A / MX / TXT / NS / ANY", defaultValue = "A")
            ),
            risk = RiskLevel.INFO,
            docsAsset = "docs/dig_lookup.md"
        ),
        ToolItem(
            id = "whois_lookup",
            categoryId = "recon",
            name = "Whois",
            termuxPackage = "whois",
            shortDescription = "Info registrar, pemilik, dan tanggal expired sebuah domain/IP.",
            commandTemplate = "whois {target}",
            params = listOf(ToolParam("target", "Domain / IP", "contoh: example.com")),
            risk = RiskLevel.INFO,
            docsAsset = "docs/whois_lookup.md"
        ),
        ToolItem(
            id = "traceroute_run",
            categoryId = "recon",
            name = "Traceroute",
            termuxPackage = "traceroute",
            shortDescription = "Lihat jalur hop jaringan menuju sebuah host.",
            commandTemplate = "traceroute {target}",
            params = listOf(ToolParam("target", "Domain / IP", "contoh: example.com")),
            risk = RiskLevel.INFO,
            docsAsset = "docs/traceroute_run.md"
        ),

        // ---------------- WEBSEC ----------------
        ToolItem(
            id = "curl_headers",
            categoryId = "websec",
            name = "Curl – Security Headers Check",
            termuxPackage = "curl",
            shortDescription = "Lihat header HTTP respons (CSP, HSTS, X-Frame-Options, dst).",
            commandTemplate = "curl -s -D - -o /dev/null {url}",
            params = listOf(ToolParam("url", "URL target", "contoh: https://example.com")),
            risk = RiskLevel.INFO,
            docsAsset = "docs/curl_headers.md"
        ),
        ToolItem(
            id = "httpx_probe",
            categoryId = "websec",
            name = "httpx – Web Probe",
            termuxPackage = "httpx",
            shortDescription = "Probe cepat: status code, judul halaman, teknologi, server header.",
            commandTemplate = "echo {url} | httpx -title -tech-detect -status-code -server",
            params = listOf(ToolParam("url", "URL target", "contoh: https://example.com")),
            risk = RiskLevel.AUTHORIZED_ONLY,
            docsAsset = "docs/httpx_probe.md"
        ),
        ToolItem(
            id = "nikto_scan",
            categoryId = "websec",
            name = "Nikto – Web Vulnerability Scan",
            termuxPackage = "nikto",
            shortDescription = "Scan misconfiguration, file berbahaya, dan versi software yang rentan.",
            commandTemplate = "nikto -h {url}",
            params = listOf(ToolParam("url", "URL target", "contoh: https://example.com")),
            risk = RiskLevel.AUTHORIZED_ONLY,
            docsAsset = "docs/nikto_scan.md"
        ),
        ToolItem(
            id = "sqlmap_scan",
            categoryId = "websec",
            name = "SQLMap – SQL Injection Tester",
            termuxPackage = "python",
            shortDescription = "Uji parameter URL terhadap celah SQL injection (butuh `pip install sqlmap`).",
            commandTemplate = "sqlmap -u \"{url}\" --batch --level={level} --risk={riskLevel}",
            params = listOf(
                ToolParam("url", "URL dengan parameter", "contoh: https://example.com/page?id=1"),
                ToolParam("level", "Level (1-5)", "1 = paling ringan", defaultValue = "1"),
                ToolParam("riskLevel", "Risk (1-3)", "1 = paling aman", defaultValue = "1")
            ),
            risk = RiskLevel.AUTHORIZED_ONLY,
            docsAsset = "docs/sqlmap_scan.md"
        ),

        // ---------------- SYSTEM ----------------
        ToolItem(
            id = "pkg_update",
            categoryId = "system",
            name = "pkg update",
            termuxPackage = null,
            shortDescription = "Refresh daftar paket dari repo Termux.",
            commandTemplate = "pkg update -y",
            risk = RiskLevel.INFO,
            docsAsset = "docs/pkg_update.md"
        ),
        ToolItem(
            id = "pkg_upgrade",
            categoryId = "system",
            name = "pkg upgrade",
            termuxPackage = null,
            shortDescription = "Upgrade semua paket terinstall ke versi terbaru.",
            commandTemplate = "pkg upgrade -y",
            risk = RiskLevel.INFO,
            docsAsset = "docs/pkg_upgrade.md"
        ),
        ToolItem(
            id = "pkg_install",
            categoryId = "system",
            name = "pkg install <nama>",
            termuxPackage = null,
            shortDescription = "Install satu paket Termux.",
            commandTemplate = "pkg install {pkgName} -y",
            params = listOf(ToolParam("pkgName", "Nama paket", "contoh: nmap, nikto, python")),
            risk = RiskLevel.INFO,
            docsAsset = "docs/pkg_install.md"
        ),
        ToolItem(
            id = "pkg_search",
            categoryId = "system",
            name = "pkg search <kata kunci>",
            termuxPackage = null,
            shortDescription = "Cari paket yang tersedia di repo Termux.",
            commandTemplate = "pkg search {query}",
            params = listOf(ToolParam("query", "Kata kunci", "contoh: scan")),
            risk = RiskLevel.INFO,
            docsAsset = "docs/pkg_search.md"
        ),
        ToolItem(
            id = "git_clone",
            categoryId = "system",
            name = "Git Clone",
            termuxPackage = "git",
            shortDescription = "Clone repository ke ~/storage atau home Termux.",
            commandTemplate = "git clone {repoUrl}",
            params = listOf(ToolParam("repoUrl", "URL repo", "contoh: https://github.com/user/repo.git")),
            risk = RiskLevel.INFO,
            docsAsset = "docs/git_clone.md"
        ),
        ToolItem(
            id = "htop_launch",
            categoryId = "system",
            name = "htop (live session)",
            termuxPackage = "htop",
            shortDescription = "Buka monitor proses interaktif langsung di sesi Termux.",
            commandTemplate = "htop",
            risk = RiskLevel.INFO,
            docsAsset = "docs/htop_launch.md",
            runInNewSession = true
        ),

        // ---------------- DEFENSE ----------------
        ToolItem(
            id = "open_ports",
            categoryId = "defense",
            name = "Cek Port Terbuka (ss)",
            termuxPackage = "iproute2",
            shortDescription = "Lihat semua port TCP/UDP yang sedang listen di device.",
            commandTemplate = "ss -tulpn",
            risk = RiskLevel.INFO,
            docsAsset = "docs/open_ports.md"
        ),
        ToolItem(
            id = "process_list",
            categoryId = "defense",
            name = "Daftar Proses Aktif",
            termuxPackage = null,
            shortDescription = "Snapshot proses yang sedang berjalan (setara top -bn1).",
            commandTemplate = "ps -ef | head -n 50",
            risk = RiskLevel.INFO,
            docsAsset = "docs/process_list.md"
        ),
        ToolItem(
            id = "disk_usage",
            categoryId = "defense",
            name = "Penggunaan Disk",
            termuxPackage = null,
            shortDescription = "Cek kapasitas storage yang terpakai.",
            commandTemplate = "df -h",
            risk = RiskLevel.INFO,
            docsAsset = "docs/disk_usage.md"
        ),
        ToolItem(
            id = "ssh_failed_watch",
            categoryId = "defense",
            name = "Pantau Percobaan Login SSH",
            termuxPackage = "openssh",
            shortDescription = "Tail log sshd Termux untuk melihat percobaan login yang gagal (fail2ban-style, non-root).",
            commandTemplate = "tail -n 100 -f \$PREFIX/var/log/sshd.log 2>/dev/null || echo 'Jalankan: sshd, lalu coba lagi'",
            risk = RiskLevel.INFO,
            docsAsset = "docs/ssh_failed_watch.md",
            runInNewSession = true
        )
    )

    fun toolsForCategory(categoryId: String): List<ToolItem> = tools.filter { it.categoryId == categoryId }

    fun byId(id: String): ToolItem? = tools.find { it.id == id }

    /** Fills {placeholders} in a command template with user-provided values. */
    fun buildCommand(tool: ToolItem, values: Map<String, String>): String {
        var cmd = tool.commandTemplate
        tool.params.forEach { p ->
            val raw = values[p.key]?.ifBlank { p.defaultValue } ?: p.defaultValue
            val safe = sanitizeArg(raw)
            cmd = cmd.replace("{${p.key}}", safe)
        }
        return cmd
    }

    /**
     * Minimal shell-arg sanitizer: strips characters that could be used to
     * chain extra commands (`;`, `|`, backticks, `$(...)`, `&&`) onto the
     * template. Templates themselves already quote values that need spaces.
     */
    private fun sanitizeArg(value: String): String {
        return value.replace(Regex("[;&|`$()<>\\n]"), "")
    }
}
