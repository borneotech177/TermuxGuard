package com.termuxguard.app.ui

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.termuxguard.app.databinding.ItemCategoryBinding
import com.termuxguard.app.model.ToolCategory

class CategoryAdapter(
    private val categories: List<ToolCategory>,
    private val onClick: (ToolCategory) -> Unit
) : RecyclerView.Adapter<CategoryAdapter.VH>() {

    inner class VH(val binding: ItemCategoryBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): VH {
        val binding = ItemCategoryBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return VH(binding)
    }

    override fun onBindViewHolder(holder: VH, position: Int) {
        val category = categories[position]
        holder.binding.categoryTitle.text = category.title
        holder.binding.categoryDesc.text = category.description
        holder.binding.root.setOnClickListener { onClick(category) }
    }

    override fun getItemCount(): Int = categories.size
}
