package com.termuxguard.app.ui

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.termuxguard.app.BuildConfig
import com.termuxguard.app.databinding.ActivityAboutBinding

class AboutActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val binding = ActivityAboutBinding.inflate(layoutInflater)
        setContentView(binding.root)
        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.versionText.text = "TermuxGuard v${BuildConfig.VERSION_NAME} (${BuildConfig.VERSION_CODE})"
    }
}
