package com.termuxguard.app.ui

import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.termuxguard.app.core.CommandResult
import com.termuxguard.app.core.CommandResultBus
import com.termuxguard.app.core.RunCommandPermissionDelegate
import com.termuxguard.app.core.TermuxCommandExecutor
import com.termuxguard.app.databinding.ActivityPackageManagerBinding
import java.util.UUID

/**
 * Dedicated screen for Termux's own package manager: update, upgrade,
 * search and install — the "lengkap dengan fitur termux seperti upgrade
 * dan update" requirement, independent of the security-tool catalog.
 */
class PackageManagerActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPackageManagerBinding
    private var currentJobId: String? = null
    private val runCommand = RunCommandPermissionDelegate(this)

    private val resultListener: (CommandResult) -> Unit = { result ->
        if (result.jobId == currentJobId) {
            runOnUiThread { showResult(result) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPackageManagerBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.toolbar.setNavigationOnClickListener { finish() }

        binding.btnUpdate.setOnClickListener { runPkg("update") }
        binding.btnUpgrade.setOnClickListener { runPkg("upgrade") }
        binding.btnSearch.setOnClickListener { runPkgWithName("search") }
        binding.btnInstall.setOnClickListener { runPkgWithName("install") }
    }

    override fun onStart() {
        super.onStart()
        CommandResultBus.subscribe(resultListener)
    }

    override fun onStop() {
        super.onStop()
        CommandResultBus.unsubscribe(resultListener)
    }

    private fun runPkg(action: String) {
        if (!guardTermux()) return
        val jobId = UUID.randomUUID().toString()
        currentJobId = jobId
        binding.pkgConsoleOutput.text = "$ pkg $action -y\n\n(menjalankan...)"
        runCommand.dispatch { TermuxCommandExecutor.runPkg(this, jobId, action) }
    }

    private fun runPkgWithName(action: String) {
        val name = binding.pkgNameInput.text?.toString()?.trim().orEmpty()
        if (name.isBlank()) {
            Toast.makeText(this, "Isi nama paket dulu", Toast.LENGTH_SHORT).show()
            return
        }
        if (!guardTermux()) return
        val safeName = name.replace(Regex("[;&|`$()<>\\n]"), "")
        val jobId = UUID.randomUUID().toString()
        currentJobId = jobId
        binding.pkgConsoleOutput.text = "$ pkg $action $safeName\n\n(menjalankan...)"
        val suffix = if (action == "install") "-y" else ""
        val pkgArgs = "$action $safeName $suffix".trim()
        runCommand.dispatch { TermuxCommandExecutor.runPkg(this, jobId, pkgArgs) }
    }

    private fun guardTermux(): Boolean {
        if (!TermuxCommandExecutor.isTermuxInstalled(this)) {
            Toast.makeText(this, getString(com.termuxguard.app.R.string.termux_not_installed_msg), Toast.LENGTH_LONG).show()
            return false
        }
        return true
    }

    private fun showResult(result: CommandResult) {
        val sb = StringBuilder()
        if (result.stdout.isNotBlank()) sb.append(result.stdout).append("\n")
        if (result.stderr.isNotBlank()) sb.append("--- stderr ---\n").append(result.stderr).append("\n")
        sb.append("\n[exit code: ${result.exitCode}]")
        binding.pkgConsoleOutput.text = sb.toString()
    }
}
