package com.termuxguard.app.ui

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.tabs.TabLayout
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.textfield.TextInputLayout
import com.termuxguard.app.core.CommandResult
import com.termuxguard.app.core.CommandResultBus
import com.termuxguard.app.core.TermuxCommandExecutor
import com.termuxguard.app.databinding.ActivityToolDetailBinding
import com.termuxguard.app.databinding.ItemParamFieldBinding
import com.termuxguard.app.model.RiskLevel
import com.termuxguard.app.model.ToolItem
import com.termuxguard.app.model.ToolRepository
import com.termuxguard.app.util.DocsLoader
import java.util.UUID

class ToolDetailActivity : AppCompatActivity() {

    private lateinit var binding: ActivityToolDetailBinding
    private lateinit var tool: ToolItem
    private val paramInputs = mutableMapOf<String, TextInputEditText>()
    private var currentJobId: String? = null

    private val resultListener: (CommandResult) -> Unit = { result ->
        if (result.jobId == currentJobId) {
            runOnUiThread { appendConsoleResult(result) }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityToolDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        val toolId = intent.getStringExtra(EXTRA_TOOL_ID) ?: return finish()
        tool = ToolRepository.byId(toolId) ?: return finish()

        binding.toolbar.title = tool.name
        binding.toolbar.setNavigationOnClickListener { finish() }
        binding.toolDesc.text = tool.shortDescription

        setupRiskBanner()
        buildParamForm()
        updateCommandPreview()
        setupTabs()
        loadDocs()

        binding.runButton.setOnClickListener { onRunClicked() }
        binding.copyOutputButton.setOnClickListener { copyConsoleOutput() }
        binding.clearConsoleButton.setOnClickListener { binding.consoleOutput.text = "" }
    }

    override fun onStart() {
        super.onStart()
        CommandResultBus.subscribe(resultListener)
    }

    override fun onStop() {
        super.onStop()
        CommandResultBus.unsubscribe(resultListener)
    }

    private fun setupRiskBanner() {
        if (tool.risk == RiskLevel.INFO) {
            binding.riskBanner.visibility = View.GONE
            return
        }
        binding.riskBanner.visibility = View.VISIBLE
        binding.riskText.text = if (tool.risk == RiskLevel.AUTHORIZED_ONLY) {
            "Tool ini melakukan scan/pengujian aktif. Hanya jalankan terhadap sistem milik Anda sendiri atau yang sudah memberi izin tertulis."
        } else {
            "Tool ini mengirim traffic ke host target. Gunakan secara bertanggung jawab."
        }
        binding.runButton.isEnabled = tool.risk != RiskLevel.AUTHORIZED_ONLY
        if (tool.risk == RiskLevel.AUTHORIZED_ONLY) {
            binding.authorizeCheckbox.setOnCheckedChangeListener { _, checked ->
                binding.runButton.isEnabled = checked
            }
        }
    }

    private fun buildParamForm() {
        tool.params.forEach { param ->
            val fieldBinding = ItemParamFieldBinding.inflate(layoutInflater, binding.paramsContainer, true)
            val layout = fieldBinding.root as TextInputLayout
            layout.hint = "${param.label} (${param.hint})"
            val input = fieldBinding.paramInput
            if (param.defaultValue.isNotBlank()) {
                input.setText(param.defaultValue)
            }
            input.addTextChangedListener(object : TextWatcher {
                override fun afterTextChanged(s: Editable?) = updateCommandPreview()
                override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
                override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            })
            paramInputs[param.key] = input
        }
    }

    private fun currentParamValues(): Map<String, String> =
        paramInputs.mapValues { it.value.text?.toString().orEmpty() }

    private fun updateCommandPreview() {
        binding.commandPreview.text = ToolRepository.buildCommand(tool, currentParamValues())
    }

    private fun setupTabs() {
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) = showPage(tab.position)
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) {}
        })
    }

    private fun showPage(index: Int) {
        binding.pageRun.visibility = if (index == 0) View.VISIBLE else View.GONE
        binding.pageConsole.visibility = if (index == 1) View.VISIBLE else View.GONE
        binding.pageDocs.visibility = if (index == 2) View.VISIBLE else View.GONE
        binding.pageAnalysis.visibility = if (index == 3) View.VISIBLE else View.GONE
    }

    private fun loadDocs() {
        val markdown = DocsLoader.read(this, tool.docsAsset)
        binding.docsText.text = markdown
        binding.analysisText.text = DocsLoader.extractSection(
            markdown,
            listOf("Membaca hasil", "Kapan dipakai", "Legal")
        )
    }

    private fun onRunClicked() {
        for (param in tool.params) {
            if (param.required && paramInputs[param.key]?.text.isNullOrBlank() && param.defaultValue.isBlank()) {
                Toast.makeText(this, "Isi dulu: ${param.label}", Toast.LENGTH_SHORT).show()
                return
            }
        }

        if (!TermuxCommandExecutor.isTermuxInstalled(this)) {
            AlertDialog.Builder(this)
                .setTitle(com.termuxguard.app.R.string.termux_not_installed_title)
                .setMessage(com.termuxguard.app.R.string.termux_not_installed_msg)
                .setPositiveButton("OK", null)
                .show()
            return
        }

        if (tool.risk == RiskLevel.AUTHORIZED_ONLY && !binding.authorizeCheckbox.isChecked) {
            Toast.makeText(this, "Centang pernyataan izin dulu sebelum menjalankan.", Toast.LENGTH_LONG).show()
            return
        }

        val command = ToolRepository.buildCommand(tool, currentParamValues())
        val jobId = UUID.randomUUID().toString()
        currentJobId = jobId

        binding.tabLayout.getTabAt(1)?.select()
        binding.consoleOutput.text = "$ $command\n\n(menjalankan di Termux...)\n"

        val mode = if (tool.runInNewSession) {
            TermuxCommandExecutor.SessionMode.NEW_SESSION
        } else {
            TermuxCommandExecutor.SessionMode.BACKGROUND
        }
        TermuxCommandExecutor.run(this, jobId, command, mode, label = tool.name)

        if (mode == TermuxCommandExecutor.SessionMode.NEW_SESSION) {
            binding.consoleOutput.text = "$ $command\n\nSesi Termux dibuka terpisah — lihat output langsung di aplikasi Termux."
        }
    }

    private fun appendConsoleResult(result: CommandResult) {
        val sb = StringBuilder()
        sb.append("$ ${binding.commandPreview.text}\n\n")
        if (result.stdout.isNotBlank()) {
            sb.append(result.stdout).append("\n")
        }
        if (result.stderr.isNotBlank()) {
            sb.append("--- stderr ---\n").append(result.stderr).append("\n")
        }
        if (result.errmsg.isNotBlank()) {
            sb.append("--- error ---\n").append(result.errmsg).append("\n")
        }
        sb.append("\n[exit code: ${result.exitCode}]")
        binding.consoleOutput.text = sb.toString()
    }

    private fun copyConsoleOutput() {
        val clipboard = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        clipboard.setPrimaryClip(ClipData.newPlainText("output", binding.consoleOutput.text))
        Toast.makeText(this, "Output disalin", Toast.LENGTH_SHORT).show()
    }

    companion object {
        const val EXTRA_TOOL_ID = "extra_tool_id"
    }
}
