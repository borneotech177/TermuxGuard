# Whois

## Fungsi
Menampilkan data registrasi domain: registrar, tanggal dibuat/kedaluwarsa, dan server nama (untuk IP: pemilik blok IP/ASN).

## Cara pakai
1. Isi domain atau IP.
2. Jalankan.

## Membaca hasil
- `Registrar:` siapa tempat domain didaftarkan.
- `Creation Date` / `Registry Expiry Date` — berguna untuk cek domain hijacking (domain diambil alih setelah lupa diperpanjang) atau menilai usia domain (domain phishing biasanya sangat baru).
- `Name Server:` menunjukkan provider DNS yang dipakai.
- Untuk IP, hasil menunjukkan rentang IP (CIDR) dan organisasi pemilik (ASN) — berguna mengetahui apakah sebuah IP milik cloud provider, ISP, atau hosting tertentu.

## Kapan dipakai
Tahap OSINT awal sebelum audit, atau verifikasi keaslian sebuah domain/IP yang mencurigakan.

## Legal
Aman — data whois bersifat publik.
