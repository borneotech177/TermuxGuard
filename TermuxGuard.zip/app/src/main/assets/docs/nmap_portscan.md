# Nmap – Port Scan (-sV --top-ports)

## Fungsi
Mengecek port TCP mana yang terbuka pada satu host, lalu mencoba mendeteksi nama & versi service yang berjalan di port tersebut.

## Cara pakai
1. Isi target dengan IP/domain tunggal (bukan subnet).
2. Isi jumlah "top ports" — nmap mengurutkan port berdasarkan yang paling umum dipakai; 100 biasanya cukup untuk audit cepat, 1000 untuk lebih menyeluruh.
3. Jalankan. Semakin banyak port, semakin lama waktunya.

## Membaca hasil
- Kolom `PORT` `STATE` `SERVICE` `VERSION`.
- `open` = port menerima koneksi — berarti ada service aktif di sana, inilah permukaan serangan (attack surface).
- `closed` = port tercapai tapi tidak ada yang listen.
- `filtered` = firewall memblokir, nmap tidak bisa pastikan statusnya.
- Service versi lama/outdated di kolom VERSION sering jadi petunjuk untuk cari CVE yang relevan (cross-check manual ke NVD/CVE database, aplikasi ini tidak melakukan exploit otomatis).

## Kapan dipakai
Setelah host discovery, untuk memetakan service apa saja yang berjalan — basis untuk hardening (tutup port yang tidak perlu) atau untuk tes keamanan lanjutan pada sistem sendiri.

## Legal
AUTHORIZED_ONLY: hanya jalankan ke host yang Anda miliki atau punya izin tertulis (misal program bug bounty yang mengizinkan port scanning).
