# pkg search <kata kunci>

## Fungsi
Mencari nama paket yang tersedia di repo Termux berdasarkan kata kunci.

## Cara pakai
1. Isi kata kunci, contoh `scan`, `python`, `net`.
2. Jalankan.

## Membaca hasil
Daftar `nama/repo versi` diikuti deskripsi singkat tiap paket yang cocok dengan kata kunci.

## Kapan dipakai
Saat tidak yakin nama persis sebuah tool sebelum menjalankan `pkg install`.
