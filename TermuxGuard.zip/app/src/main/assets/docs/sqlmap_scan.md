# SQLMap – SQL Injection Tester

## Fungsi
Mengotomasi deteksi dan (opsional) eksploitasi celah SQL injection pada parameter URL/form sebuah aplikasi web.

## Instalasi
`pkg install python -y` lalu `pip install sqlmap` (atau `pip install --break-system-packages sqlmap` di Termux terbaru).

## Cara pakai
1. Isi URL yang mengandung parameter, contoh `https://target.com/page.php?id=1`.
2. Level (1-5): seberapa banyak titik injeksi yang dicoba — level 1 paling cepat & ringan.
3. Risk (1-3): seberapa "agresif" payload yang dicoba — risk 1 paling aman untuk data target (tidak ada payload yang berpotensi merusak).
4. Jalankan dengan `--batch` (otomatis jawab default ke semua prompt, tanpa interaksi manual).

## Membaca hasil
- `[INFO] testing ...` = proses pengujian tiap jenis teknik injeksi (boolean-based, time-based, error-based, UNION).
- `Parameter: id (GET)` diikuti `Type:` dan `Payload:` = celah ditemukan, beserta payload yang berhasil.
- Jika muncul `all tested parameters do not appear to be injectable` = tidak ditemukan celah pada level/risk saat ini (bisa jadi perlu level lebih tinggi, atau memang aman).

## Kapan dipakai
Hanya untuk menguji aplikasi web milik sendiri atau yang sudah eksplisit mengizinkan pengujian keamanan (pentest berizin, program bug bounty).

## Legal — PENTING
AUTHORIZED_ONLY. Menjalankan sqlmap ke sistem tanpa izin adalah percobaan akses ilegal di hampir semua yurisdiksi, termasuk Indonesia (UU ITE). Aplikasi ini tidak mengirim payload apa pun tanpa Anda menekan tombol jalankan secara eksplisit, dan tetap menjadi tanggung jawab penuh pengguna untuk memastikan target dalam lingkup izin.
