# Curl – Security Headers Check

## Fungsi
Mengambil HTTP response header sebuah website tanpa mengunduh body-nya, untuk mengecek konfigurasi keamanan header.

## Cara pakai
1. Isi URL lengkap dengan skema (`https://...`).
2. Jalankan.

## Membaca hasil
Header yang perlu diperhatikan:
- `Strict-Transport-Security` — ada/tidaknya HSTS (paksa HTTPS).
- `Content-Security-Policy` — kontrol sumber script/style, mitigasi XSS.
- `X-Frame-Options` / `frame-ancestors` — mitigasi clickjacking.
- `X-Content-Type-Options: nosniff` — cegah MIME sniffing.
- `Server:` / `X-Powered-By:` — bisa membocorkan versi software (informasi yang berguna bagi penyerang, idealnya disembunyikan).

## Kapan dipakai
Langkah pertama audit keamanan website sendiri — cek cepat tanpa scan berat, aman dijalankan ke hampir semua situs publik karena hanya request HTTP biasa.

## Legal
Risiko rendah (setara membuka website lewat browser), tapi tetap hormati robots.txt dan rate limit jika target bukan milik Anda.
