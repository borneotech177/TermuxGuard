# pkg update

## Fungsi
Menyinkronkan daftar paket lokal dengan repo Termux terbaru (seperti `apt update` di Debian/Ubuntu). Tidak menginstall/upgrade apa pun, hanya memperbarui index.

## Cara pakai
Jalankan langsung, tidak perlu parameter. Lakukan ini sebelum `pkg upgrade` atau `pkg install`.

## Membaca hasil
- `Fetched ... B in ...s` = berhasil mengunduh index repo.
- `All packages are up to date` bisa muncul jika sudah mutakhir.
- Error `Failure while downloading` biasanya masalah jaringan/mirror — coba `termux-change-repo` untuk ganti mirror.

## Kapan dipakai
Rutin sebelum install tool baru, memastikan Anda mendapat versi terbaru yang tersedia di repo.
