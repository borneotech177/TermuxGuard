# Dig – DNS Lookup

## Fungsi
Menanyakan langsung ke DNS resolver untuk melihat record yang terdaftar pada sebuah domain.

## Cara pakai
1. Isi domain target, contoh `example.com`.
2. Pilih tipe record: `A` (IPv4), `AAAA` (IPv6), `MX` (mail server), `TXT` (SPF/DKIM/verifikasi), `NS` (nameserver), atau `ANY`.
3. Jalankan.

## Membaca hasil
- Kolom hasil: `nama` `TTL` `class` `type` `value`.
- Record `A` menunjukkan IP yang dipakai domain — bandingkan dengan IP server yang Anda kenal untuk deteksi DNS hijack/typosquatting.
- Record `TXT` berisi `v=spf1 ...` menandakan konfigurasi anti-spoofing email (SPF).
- Record `NS` menunjukkan siapa yang mengelola DNS domain tersebut.

## Kapan dipakai
Audit konfigurasi domain sendiri, verifikasi propagasi DNS setelah ganti hosting, atau riset pasif (OSINT) tanpa menyentuh server target sama sekali.

## Legal
Aman — ini hanya query ke server DNS publik, bukan ke server target itu sendiri.
