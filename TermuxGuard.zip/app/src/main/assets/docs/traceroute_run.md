# Traceroute

## Fungsi
Menampilkan setiap router (hop) yang dilewati paket data dari HP Anda menuju host target, beserta waktu tempuhnya.

## Cara pakai
1. Isi domain/IP target.
2. Jalankan — bisa memakan waktu 10-30 detik karena menunggu respons tiap hop.

## Membaca hasil
- Tiap baris bernomor adalah satu hop/router, dengan 3 nilai waktu (ms) dari 3 kali percobaan.
- `* * *` berarti hop tersebut tidak merespons (biasa terjadi, banyak router memblokir traceroute) — bukan berarti jalur putus.
- Lonjakan waktu drastis di satu hop bisa menunjukkan titik kemacetan/latency jaringan.

## Kapan dipakai
Diagnosa masalah konektivitas, memahami topologi jaringan menuju server, atau melihat apakah traffic melewati CDN/load balancer tertentu.

## Legal
Aman — traceroute adalah tool diagnostik standar, tidak mengubah apa pun di sisi target.
