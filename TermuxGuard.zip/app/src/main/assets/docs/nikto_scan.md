# Nikto – Web Vulnerability Scan

## Fungsi
Scanner klasik yang memeriksa ribuan file/path berbahaya yang diketahui, misconfiguration server, header keamanan yang hilang, dan versi software web server/CMS yang rentan.

## Instalasi
`pkg install nikto -y` (butuh Perl, otomatis ter-install sebagai dependency).

## Cara pakai
1. Isi URL target lengkap dengan skema.
2. Jalankan — scan penuh bisa makan waktu beberapa menit tergantung ukuran situs.

## Membaca hasil
- Tiap baris `+ ...` adalah satu temuan.
- Contoh: `+ Server leaks inode via ETags` — header bocor info internal server.
- `+ The X-XSS-Protection header is not defined` — header keamanan browser tidak diset.
- `+ OSVDB-XXXX:` merujuk ke entri database kerentanan lama — cek manual relevansinya, karena nikto cenderung banyak false positive.
- Di akhir ada ringkasan jumlah item yang diperiksa dan waktu scan.

## Kapan dipakai
Audit cepat terhadap konfigurasi website sebelum go-live, atau pengecekan berkala pada server sendiri.

## Legal
AUTHORIZED_ONLY. Nikto cukup "berisik" (banyak request dalam waktu singkat) dan hampir pasti akan tercatat di log/WAF target — hanya jalankan pada sistem milik sendiri atau yang sudah mengizinkan.
