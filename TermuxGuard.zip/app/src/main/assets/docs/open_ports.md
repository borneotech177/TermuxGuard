# Cek Port Terbuka (ss)

## Fungsi
Menampilkan semua socket TCP/UDP yang sedang listen di device Anda sendiri — yaitu pintu masuk mana saja yang terbuka dari device ini.

## Cara pakai
Jalankan langsung, tidak perlu parameter.

## Membaca hasil
- Kolom `Netid` (tcp/udp), `State` (LISTEN), `Local Address:Port`, `Process`.
- Port `127.0.0.1:xxxx` hanya bisa diakses dari device itu sendiri (aman).
- Port `0.0.0.0:xxxx` atau `*:xxxx` bisa diakses dari jaringan luar — periksa apakah service ini memang sengaja dibuka (misal sshd Termux) atau tidak dikenal (potensi backdoor/malware).

## Kapan dipakai
Audit keamanan device sendiri secara berkala — bagian dari "pertahanan" (defense), memastikan tidak ada service tak dikenal yang terbuka ke jaringan.
