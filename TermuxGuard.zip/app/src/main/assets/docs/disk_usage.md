# Penggunaan Disk

## Fungsi
Menampilkan kapasitas dan pemakaian storage yang terlihat oleh Termux.

## Cara pakai
Jalankan langsung.

## Membaca hasil
- Kolom `Size`, `Used`, `Avail`, `Use%`, `Mounted on`.
- `Use%` mendekati 100% berarti storage hampir penuh — bisa menyebabkan tool gagal menulis file (misal hasil scan nikto/sqlmap) atau log scan terpotong.

## Kapan dipakai
Cek rutin sebelum menjalankan scan yang menghasilkan output besar (sqlmap dengan banyak payload, log nikto panjang).
