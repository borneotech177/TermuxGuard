# Daftar Proses Aktif

## Fungsi
Snapshot semua proses yang berjalan di environment Termux saat ini.

## Cara pakai
Jalankan langsung.

## Membaca hasil
- Kolom `UID`, `PID`, `PPID`, `CMD` (nama perintah/proses).
- Proses dengan nama aneh/acak atau yang tidak Anda kenal menjalankannya patut dicurigai — cross-check dengan `ss -tulpn` untuk lihat apakah proses itu juga membuka port jaringan.

## Kapan dipakai
Deteksi dini proses mencurigakan (bagian dari monitoring & defense), terutama setelah menginstall paket/skrip dari sumber yang kurang dipercaya.
