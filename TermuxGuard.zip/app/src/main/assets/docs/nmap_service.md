# Nmap – Service/OS Detection (-A)

## Fungsi
Mode agresif nmap: menggabungkan deteksi versi service, OS fingerprinting, traceroute, dan script NSE default (banner grabbing, deteksi vuln ringan bawaan nmap).

## Cara pakai
1. Isi target IP/domain tunggal.
2. Jalankan — ini scan paling lama dan paling "berisik" di jaringan, bisa memicu alert IDS/IPS.

## Membaca hasil
- Bagian atas: daftar port + service + versi (sama seperti port scan biasa).
- `Service Info: OS:` menunjukkan tebakan sistem operasi target.
- `| <nama script>:` adalah output script NSE, misalnya header HTTP, banner SSH, atau info SMB.
- `TRACEROUTE` di bagian bawah menunjukkan hop jaringan menuju target.

## Kapan dipakai
Audit mendalam terhadap satu host yang sudah dipastikan dalam scope izin Anda (misal server pribadi) untuk melihat gambaran lengkap sebelum hardening.

## Legal
AUTHORIZED_ONLY. Scan ini jauh lebih mudah terdeteksi sebagai aktivitas mencurigakan — jangan arahkan ke host yang bukan milik Anda.
