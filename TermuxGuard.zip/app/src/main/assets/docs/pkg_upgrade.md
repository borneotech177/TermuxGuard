# pkg upgrade

## Fungsi
Mengupgrade seluruh paket yang sudah terinstall ke versi terbaru yang ada di index repo (jalankan `pkg update` dulu agar index mutakhir).

## Cara pakai
Jalankan langsung. Pada upgrade besar, Termux kadang menampilkan prompt konfigurasi file (`Y/I/N/O/D/Z`) — karena dijalankan via RUN_COMMAND non-interaktif, sebaiknya sesekali buka Termux manual untuk upgrade besar yang butuh keputusan interaktif.

## Membaca hasil
- Daftar paket yang di-upgrade beserta versi lama → baru.
- `Nothing to upgrade` = semua sudah versi terbaru.

## Kapan dipakai
Berkala (mingguan/bulanan) agar tools seperti nmap/nikto/sqlmap selalu punya database signature terbaru dan patch keamanan terbaru.
