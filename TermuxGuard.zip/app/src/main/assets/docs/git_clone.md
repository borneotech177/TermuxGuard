# Git Clone

## Fungsi
Mengunduh (clone) sebuah repository git ke penyimpanan Termux.

## Cara pakai
1. Isi URL repo, contoh `https://github.com/user/repo.git`.
2. Jalankan — hasil clone masuk ke `~/<nama-repo>`.

## Membaca hasil
- `Cloning into '<nama-repo>'...` lalu progress `Receiving objects: xx%`.
- `fatal: repository not found` = URL salah/repo private tanpa autentikasi.

## Kapan dipakai
Mengambil skrip/wordlist/tool tambahan dari GitHub untuk dipakai di Termux, atau mem-backup konfigurasi sendiri.

## Keamanan
Periksa dulu isi repo (lewat GitHub di browser) sebelum menjalankan script apa pun di dalamnya — jangan asal `bash install.sh` dari sumber yang tidak dipercaya.
