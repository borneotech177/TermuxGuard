# httpx – Web Probe

## Fungsi
Tool dari ProjectDiscovery untuk probing cepat banyak URL sekaligus: status code, judul halaman, teknologi yang terdeteksi (CMS, framework), dan header server.

## Instalasi
`pkg install golang -y` lalu `go install github.com/projectdiscovery/httpx/cmd/httpx@latest`, atau cari lewat `pkg search httpx` jika tersedia di repo.

## Cara pakai
1. Isi URL target.
2. Jalankan.

## Membaca hasil
- `[200]` dsb = HTTP status code. 200 OK, 301/302 redirect, 403 forbidden, 500 error server.
- `[title]` menunjukkan isi tag `<title>` halaman.
- `[tech]` menampilkan teknologi terdeteksi, misal `[WordPress, nginx, PHP]` — ini membantu mencari kerentanan spesifik versi software tersebut.
- `[server]` menunjukkan header Server.

## Kapan dipakai
Recon cepat sebelum scan lebih dalam, terutama saat punya banyak subdomain/URL untuk disortir mana yang aktif dan menarik untuk diperiksa lebih lanjut.

## Legal
AUTHORIZED_ONLY untuk penggunaan scanning masif — gunakan hanya pada domain/subdomain milik sendiri atau scope program bug bounty resmi.
