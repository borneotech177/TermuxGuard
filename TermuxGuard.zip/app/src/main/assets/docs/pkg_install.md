# pkg install <nama>

## Fungsi
Menginstall satu paket dari repo Termux.

## Cara pakai
1. Isi nama paket persis seperti di repo (gunakan `pkg search` dulu jika tidak yakin).
2. Jalankan.

## Membaca hasil
- `Setting up <paket>...` = berhasil.
- `Unable to locate package` = nama salah atau belum ada di index (jalankan `pkg update` dulu).

## Kapan dipakai
Setiap kali membutuhkan tool baru yang belum ada di Termux, misalnya `nmap`, `nikto`, `git`, `python`, `openssh`.
