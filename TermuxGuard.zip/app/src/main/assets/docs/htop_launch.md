# htop (live session)

## Fungsi
Monitor proses & resource (CPU, RAM) secara interaktif dan real-time.

## Cara pakai
Tombol "Jalankan" akan membuka sesi Termux baru (bukan mode headless) karena htop butuh layar interaktif penuh. Tekan `q` di Termux untuk keluar.

## Membaca hasil
- Baris atas: grafik pemakaian tiap core CPU dan RAM.
- Tabel bawah: daftar proses, kolom `CPU%`, `MEM%`, `COMMAND`.
- Tekan `F6` untuk sort by kolom tertentu, `F9` untuk kill proses yang dipilih.

## Kapan dipakai
Memantau beban sistem saat menjalankan scan berat (nmap -A, nikto) secara bersamaan, atau mendeteksi proses background yang mencurigakan menghabiskan resource.
