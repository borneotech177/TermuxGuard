# Nmap – Host Discovery (-sn)

## Fungsi
Mengirim ping/ARP ke seluruh IP dalam satu subnet untuk mengetahui host mana yang sedang menyala, tanpa melakukan scan port.

## Cara pakai
1. Isi target dengan subnet dalam notasi CIDR, misal `192.168.1.0/24` untuk scan seluruh 192.168.1.1–254.
2. Jalankan. Proses ini cepat (beberapa detik–1 menit tergantung jumlah host).

## Membaca hasil
- Baris `Nmap scan report for <ip>` menandakan host itu hidup.
- `Host is up (0.0012s latency)` menunjukkan host merespons dalam 1.2ms — latency rendah biasanya host di jaringan lokal yang sama.
- Tidak muncul di hasil ≠ pasti mati; beberapa host memblokir ICMP/ARP probe (firewall).

## Kapan dipakai
Langkah pertama audit jaringan: tahu dulu host mana yang perlu diperiksa lebih lanjut sebelum port scan yang lebih "berisik".

## Legal
Scan subnet rumah/kantor sendiri aman. Jangan scan subnet milik ISP/orang lain tanpa izin.
