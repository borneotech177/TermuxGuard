# Pantau Percobaan Login SSH (fail2ban-style)

## Fungsi
Termux tidak punya fail2ban asli (butuh root untuk iptables), tapi untuk belajar konsep "deteksi brute-force", tool ini mem-`tail -f` log sshd Termux (`openssh`) agar Anda bisa melihat percobaan koneksi/login secara real-time.

## Prasyarat
1. `pkg install openssh -y`
2. Set password: `passwd`
3. Jalankan server: `sshd` (default port 8022 di Termux)
4. Baru jalankan monitor ini di sesi terpisah.

## Cara pakai
Tombol "Jalankan" membuka sesi Termux baru yang terus menampilkan log baru (live tail). Tekan `Ctrl+C` untuk berhenti.

## Membaca hasil
- Baris berisi `Failed password` / `Invalid user` dari IP tertentu berulang kali dalam waktu singkat = indikasi percobaan brute-force.
- Baris `Accepted password` = login berhasil — pastikan itu Anda sendiri.

## Konsep lanjutan (manual, di luar app)
Untuk benar-benar memblokir IP (seperti fail2ban), di luar Termux (karena butuh akses root/iptables) Anda bisa pakai firewall di router/VPS. Di dalam Termux tanpa root, mitigasi realistis adalah: ganti port default, pakai key-based auth (nonaktifkan password login), dan batasi `AllowUsers` di `sshd_config`.

## Kapan dipakai
Belajar konsep intrusion detection dasar dan mengamankan akses SSH ke device sendiri.
